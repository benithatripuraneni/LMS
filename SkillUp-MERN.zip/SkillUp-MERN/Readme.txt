1. Run npm install command in present, client and server directories.
2. Add a .env file to server/config folder and mention MongoDB Database URL as DB_URI = "Insert link here".
3. Enter the command <npm run dev> in the current directory to start the project.