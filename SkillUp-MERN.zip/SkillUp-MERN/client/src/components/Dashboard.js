import React, { Component } from "react";
// import { BrowserRouter as Router} from "react-router-dom";
// import "./style1.css";

export default class Dashboard extends Component {
    render() {
        console.log("Entered Dashboard");
        return(
            // <Router>
                //{/* <link rel="stylesheet" href="./style1.css"></link> */}
                <div id = "uday">
                    <h1>Dashboard</h1>
                </div>
             //{/* </Router> */}
        );
    }
}

